"""gr.Workflow — high-level API for building and launching AI pipelines."""

from __future__ import annotations

import base64
import dataclasses
import hashlib
import inspect
import json
import logging
import mimetypes
import os
import re
import secrets
import sys
import tempfile
import threading
import types
import urllib.parse
import warnings
import webbrowser
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING, Optional, TypedDict, Union, get_type_hints

import anyio
import httpx
from gradio_client import Client, handle_file
from gradio_client import utils as client_utils
from huggingface_hub import HfApi
from huggingface_hub import get_token as hf_get_token

import gradio as gr
from gradio.blocks import Blocks
from gradio.components.workflowcanvas import WorkflowCanvas
from gradio.context import Context
from gradio.helpers import special_args as _special_args
from gradio.oauth import OAuthProfile, OAuthToken
from gradio.route_utils import Request
from gradio.utils import (
    colab_check,
    get_space,
    get_upload_folder,
    is_in_or_equal,
)
from gradio.workflow_provider_shims import call_with_recovery

if TYPE_CHECKING:
    from gradio.workflow_api import WorkflowEndpointManager

_HF_CLIENT = httpx.Client(
    base_url="https://huggingface.co",
    timeout=15,
    headers={"User-Agent": "gradio-workflow"},
    limits=httpx.Limits(max_keepalive_connections=8, max_connections=16),
)
_SEARCH_POOL = ThreadPoolExecutor(max_workers=4, thread_name_prefix="hf-search")

_CURATED_DATASET_REPO = "gradio/workflow-curated"
_CURATED_DATASET_FILE = "curated.json"
_CURATED_TTL_SECONDS = 3600.0

_INJECTED_TYPES = frozenset({OAuthToken, OAuthProfile, Request})


def _is_injected_param(hint: object) -> bool:
    if hint in _INJECTED_TYPES:
        return True
    if getattr(hint, "__origin__", None) is Union:
        args = hint.__args__  # type: ignore[union-attr]
        non_none = [a for a in args if a is not type(None)]
        return len(non_none) == 1 and non_none[0] in _INJECTED_TYPES
    if isinstance(hint, types.UnionType):
        non_none = [a for a in hint.__args__ if a is not type(None)]
        return len(non_none) == 1 and non_none[0] in _INJECTED_TYPES
    return False


class _CuratedCache(TypedDict):
    fetched_at: float
    items: Optional[list[dict]]


_CURATED_CACHE: _CuratedCache = {"fetched_at": 0.0, "items": None}
_CURATED_LOCK = threading.Lock()


def _bundled_snapshot_path() -> str:
    return os.path.join(os.path.dirname(__file__), "_workflow_curated_snapshot.json")


def _load_bundled_snapshot() -> list[dict]:
    try:
        with open(_bundled_snapshot_path(), encoding="utf-8") as f:
            payload = json.load(f)
        items = payload.get("items") if isinstance(payload, dict) else payload
        return items if isinstance(items, list) else []
    except Exception as e:
        logger.warning("workflow curated snapshot unreadable: %s", e)
        return []


def _fetch_curated_from_hub() -> Optional[list[dict]]:
    try:
        from huggingface_hub import hf_hub_download

        local = hf_hub_download(
            repo_id=_CURATED_DATASET_REPO,
            filename=_CURATED_DATASET_FILE,
            repo_type="dataset",
        )
        with open(local, encoding="utf-8") as f:
            payload = json.load(f)
        items = payload.get("items") if isinstance(payload, dict) else payload
        if isinstance(items, list):
            return items
        return None
    except Exception as e:
        logger.info("curated dataset fetch failed: %s", e)
        return None


def _load_curated() -> list[dict]:
    import time

    now = time.monotonic()
    with _CURATED_LOCK:
        cached_at = _CURATED_CACHE["fetched_at"]
        cached_items = _CURATED_CACHE["items"]
        if cached_items is not None and (now - cached_at) < _CURATED_TTL_SECONDS:
            return cached_items

    live = _fetch_curated_from_hub()
    items: list[dict] = live if live is not None else _load_bundled_snapshot()

    with _CURATED_LOCK:
        cached_at2 = _CURATED_CACHE["fetched_at"]
        if (now - cached_at2) >= _CURATED_TTL_SECONDS:
            _CURATED_CACHE["fetched_at"] = now
            _CURATED_CACHE["items"] = items
        else:
            cached = _CURATED_CACHE["items"]
            if cached is not None:
                items = cached
    return items


logger = logging.getLogger(__name__)

# Scalar-only — everything else (str, list, dict, custom classes) falls through
# to the default "text" port type, which round-trips as JSON.
_PY_TO_PORT = {int: "number", float: "number", bool: "boolean"}
_SANITIZE_RE = re.compile(r"[^a-zA-Z0-9_-]")


def _build_edges(
    edges_spec: list[tuple[str, str]],
    nodes: list[dict],
) -> list[dict]:
    def resolve(spec: str, ports_key: str) -> tuple[str, str, str]:
        fn_name, _, port_hint = spec.partition(".")
        fn_name = fn_name.strip()
        port_hint = port_hint.strip() or None

        node = next((n for n in nodes if n.get("fn") == fn_name), None)
        if node is None:
            raise ValueError(
                f"edges: no function '{fn_name}' in bind dict. "
                f"Available: {[n['fn'] for n in nodes]}"
            )

        ports = node[ports_key]
        if not ports:
            raise ValueError(f"edges: node '{fn_name}' has no {ports_key}")

        if port_hint is None:
            port = ports[0]
            return node["id"], port["id"], port.get("type", "text")

        port = next(
            (p for p in ports if p["label"] == port_hint or p["id"] == port_hint),
            None,
        )
        if port is None:
            raise ValueError(
                f"edges: no {ports_key[:-1]} port '{port_hint}' on '{fn_name}'. "
                f"Available: {[p['label'] for p in ports]}"
            )
        return node["id"], port["id"], port.get("type", "text")

    result = []
    for i, (from_spec, to_spec) in enumerate(edges_spec):
        from_node_id, from_port_id, edge_type = resolve(from_spec, "outputs")
        to_node_id, to_port_id, _ = resolve(to_spec, "inputs")
        result.append(
            {
                "id": f"edge_{i}",
                "from_node_id": from_node_id,
                "from_port_id": from_port_id,
                "to_node_id": to_node_id,
                "to_port_id": to_port_id,
                "type": edge_type,
            }
        )
    return result


def _workflow_from_bind(
    bound: dict[str, Callable],
    edges: list[tuple[str, str]] | None = None,
    name: str = "My Workflow",
) -> str:
    # No coordinates: where a node sits is per-viewer state the canvas keeps in
    # each visitor's localStorage, so a generated workflow just declares the
    # graph and lets the canvas auto-arrange it on first open.
    nodes = []
    for fn_name, fn in bound.items():
        try:
            sig = inspect.signature(fn)
        except (ValueError, TypeError):
            sig = inspect.Signature()

        try:
            _hints = get_type_hints(fn)
        except Exception:
            _hints = getattr(fn, "__annotations__", {})
        inputs = [
            {
                "id": f"in_{p}",
                "label": p,
                "type": _PY_TO_PORT.get(param.annotation, "text"),
            }
            for p, param in sig.parameters.items()
            if p != "self" and not _is_injected_param(_hints.get(p))
        ]
        outputs = [
            {
                "id": "out_0",
                "label": "output",
                "type": _PY_TO_PORT.get(sig.return_annotation, "text"),
            }
        ]

        if not inputs:
            inputs = [{"id": "in_0", "label": "input", "type": "text"}]

        nodes.append(
            {
                "id": f"fn_{fn_name}",
                "source": "fn",
                "fn": fn_name,
                "kind": "transform",
                "label": fn_name,
                "width": 220,
                "inputs": inputs,
                "outputs": outputs,
                "data": {},
            }
        )

    edge_dicts = _build_edges(edges or [], nodes)
    return json.dumps(
        {"version": "1", "name": name, "nodes": nodes, "edges": edge_dicts}
    )


def _get_locally_saved_hf_token() -> str | None:
    """Return the local Hugging Face token when running outside Spaces.

    Avoid reading a Space's token/secret here: `get_token` is exposed to the
    browser so the workflow canvas can authenticate local apps with the user's
    `huggingface_hub login` token.
    """
    if get_space() is not None:
        return None
    return hf_get_token()


# Per-process secret granting write access to local Workflow apps, in the same
# spirit as Jupyter notebook tokens. The full URL (printed at launch) carries it
# as a query parameter; the frontend then persists it as a cookie. Share-link
# visitors and tunnelled requests never see it, so they get read-only access
# and no access to the host's local HF token.
WRITE_TOKEN = secrets.token_urlsafe(32)

_WRITE_TOKEN_COOKIE_PREFIX = "gradio_workflow_write_token"
_WRITE_TOKEN_HEADER = "x-gradio-workflow-write-token"


def _request_has_write_token(request: Request | None) -> bool:
    """True when the request carries the per-process write token, checked in
    header → cookie → query-param order (mirrors trackio's scheme). The cookie
    name is prefix-matched because the frontend suffixes it with the port —
    cookies are shared across ports on the same host, so two local apps would
    otherwise clobber each other."""
    if request is None:
        return False
    try:
        headers = {k.lower(): v for k, v in dict(request.headers or {}).items()}
    except Exception:
        return False
    header_value = headers.get(_WRITE_TOKEN_HEADER)
    if header_value:
        return secrets.compare_digest(header_value, WRITE_TOKEN)
    for cookie in headers.get("cookie", "").split(";"):
        name, _, value = cookie.strip().partition("=")
        if (
            name.startswith(_WRITE_TOKEN_COOKIE_PREFIX)
            and value
            and secrets.compare_digest(urllib.parse.unquote(value), WRITE_TOKEN)
        ):
            return True
    try:
        query_value = request.query_params.get("write_token")
    except Exception:
        query_value = None
    if query_value:
        return secrets.compare_digest(query_value, WRITE_TOKEN)
    return False


def _should_auto_open_browser() -> bool:
    """Whether `launch()` should open a browser tab on the write-access link
    without being asked, the way `jupyter notebook` opens its token URL.

    Only done when a browser on this machine is plausibly the right place to
    open it, so headless servers, containers, CI and remote kernels keep the
    old print-the-link-only behavior. Set `GRADIO_WORKFLOW_INBROWSER=false` to
    opt out, or pass `inbrowser=` explicitly to bypass this entirely.
    """
    env = os.getenv("GRADIO_WORKFLOW_INBROWSER", "").strip().lower()
    if env in ("0", "false", "no", "off"):
        return False
    if env in ("1", "true", "yes", "on"):
        return True
    if get_space() is not None:
        # No write token to hand out, and no browser on the Space's container.
        return False
    if "PYTEST_CURRENT_TEST" in os.environ or os.getenv("CI", "").lower() in (
        "1",
        "true",
    ):
        return False
    if colab_check():
        # The kernel runs on Google's machine, so a tab would open there.
        return False
    if os.environ.get("BROWSER"):
        # Explicitly configured (e.g. VS Code Remote forwards this back to the
        # local machine), and `webbrowser` honors it first.
        return True
    if os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_TTY"):
        return False
    if sys.platform.startswith("linux") and not (
        os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")
    ):
        # Headless Linux: `webbrowser` may fall back to a terminal browser and
        # take over the console the app is logging to.
        return False
    try:
        webbrowser.get()
    except webbrowser.Error:
        return False
    return True


# Shared instance: whoami(cache=True) caches per token on the HfApi instance,
# which matters because whoami-v2 is heavily rate-limited.
_hf_api = HfApi()


def _oauth_token_has_space_write_access(oauth_token: str | None) -> bool:
    """On Spaces, write access belongs to the Space owner: the OAuth user must
    be the owning user, or an admin/write member of the owning org."""
    space_id = get_space()
    if not space_id or not oauth_token:
        return False
    try:
        who = _hf_api.whoami(token=oauth_token, cache=True)
    except Exception:
        return False
    owner = os.getenv("SPACE_AUTHOR_NAME") or space_id.split("/")[0]
    if who.get("name") == owner:
        return True
    return any(
        org.get("name") == owner and org.get("roleInOrg") in ("admin", "write")
        for org in who.get("orgs", [])
    )


def has_write_access(
    request: Request | None = None, token: OAuthToken | None = None
) -> bool:
    """Whether this request may modify the workflow (and, locally, use the
    host's saved HF token). Locally: requires the launch-time write token.
    On Spaces: requires the OAuth user to own the Space (or have org write)."""
    if get_space() is not None:
        return _oauth_token_has_space_write_access(token.token if token else None)
    return _request_has_write_token(request)


def _resolve_token(
    data: list, idx: int, token, request: Request | None = None
) -> str | None:
    manual = data[idx] if len(data) > idx else None
    if manual:
        return manual
    if token:
        return token.token
    if _request_has_write_token(request):
        return _get_locally_saved_hf_token()
    return None


def _hf_request(url: str, hf_token: str | None, timeout: int = 15) -> str:
    headers = {"Authorization": f"Bearer {hf_token}"} if hf_token else {}
    resp = _HF_CLIENT.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()
    return resp.text


def _save_tmp(result, ext: str) -> dict:
    directory = get_upload_folder()
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, f"workflow_{os.urandom(8).hex()}.{ext}")
    if hasattr(result, "save"):
        result.save(path)
    else:
        with open(path, "wb") as f:
            f.write(result)
    url = f"/gradio_api/file={client_utils.encode_file_path(path)}"
    return {"path": path, "url": url, "is_file": True}


def _file_ref(a) -> str:
    """Normalize a file-shaped argument down to one reference string.

    `path` wins over `url` so a file that names both is chained by the local
    copy rather than by a `/gradio_api/file=` URL only this app can serve. A
    canvas file value carries no `path` at all (`FileValue` in
    `js/workflowcanvas/workflow/workflow-types.ts`), so the prefix comes off
    here and callers get the local path either way.

    The URL branch is percent-encoded, so it is unquoted on the way out. That
    unquoting stays inside the branch: a `path` that wins can itself hold a
    literal `%20`, which must survive as part of the filename.
    """
    src = (a.get("path") or a.get("url") or "") if isinstance(a, dict) else a
    if not isinstance(src, str) or not src:
        return ""
    if src.startswith(("data:", "http://", "https://")):
        return src
    if src.startswith("/gradio_api/file="):
        return urllib.parse.unquote(src.removeprefix("/gradio_api/file="))
    return src


def _sendable_ref(a) -> str:
    """Return the reference for `a` only if it is this app's to send, else "".

    The arguments to an operator arrive as the caller's own JSON, so a
    file-shaped one names whatever path they choose. Two references are safe to
    forward: a `data:` or absolute http(s) URL, which this process never reads
    off disk, and a path under the upload folder, which holds only what the app
    itself wrote. Every other path is someone else's file, so it is refused
    rather than read.
    """
    src = _file_ref(a)
    if src.startswith(("data:", "http://", "https://")):
        return src
    return src if src and is_in_or_equal(src, get_upload_folder()) else ""


def _chat_image_url(a) -> str:
    """Return an image reference a provider can actually resolve.

    Chat completions send images by reference, and the provider — not this
    process — is what dereferences them. A local path or a relative
    `/gradio_api/file=` URL is meaningless there, so those are inlined as a
    data URI. Absolute http(s) URLs are passed through, though note the
    provider still has to be able to fetch them.
    """
    src = _file_ref(a)
    if not src or src.startswith(("data:", "http://", "https://")):
        return src
    if not os.path.isfile(src) or not is_in_or_equal(src, get_upload_folder()):
        return src
    mime = mimetypes.guess_type(src)[0] or "image/png"
    with open(src, "rb") as f:
        return f"data:{mime};base64,{base64.b64encode(f.read()).decode()}"


def _classify_error(e: Exception) -> dict:
    http_status: int | None = None
    response = getattr(e, "response", None)
    if response is not None:
        http_status = getattr(response, "status_code", None)
    if http_status is None:
        http_status = getattr(e, "status_code", None)

    if http_status in (401, 403):
        return {
            "error_type": "auth",
            "suggestion": "Sign in with your HF account to use this model",
        }
    if http_status == 404:
        return {
            "error_type": "not_found",
            "suggestion": "Space not found — it may have been deleted or renamed",
        }
    if http_status == 429:
        return {"error_type": "quota"}

    type_name = type(e).__name__
    if type_name in (
        "RepositoryNotFoundError",
        "EntryNotFoundError",
        "RevisionNotFoundError",
    ):
        return {
            "error_type": "not_found",
            "suggestion": "Space not found — it may have been deleted or renamed",
        }
    if type_name == "GatedRepoError":
        return {
            "error_type": "auth",
            "suggestion": "Sign in with your HF account to use this model",
        }

    title = getattr(e, "title", None) or ""
    message = getattr(e, "message", None) or str(e)
    full = f"{title} {message}".lower()

    if "zerogpu" in full or ("gpu" in full and "worker" in full):
        return {"error_type": "gpu"}
    if "quota" in full or "rate limit" in full or "rate_limit" in full:
        return {"error_type": "quota"}
    if "sleeping" in full or "paused" in full:
        return {
            "error_type": "sleeping",
            "suggestion": "Space is sleeping or paused — try again in a minute",
        }
    if (
        "unauthorized" in full
        or "authentication" in full
        or "log in" in full
        or "api_key" in full
        or "api key" in full
    ):
        return {
            "error_type": "auth",
            "suggestion": "Sign in with your HF account to use this model",
        }
    if "not found" in full or "repository not found" in full:
        return {
            "error_type": "not_found",
            "suggestion": "Space not found — it may have been deleted or renamed",
        }
    if "build_error" in full or "build error" in full:
        return {
            "error_type": "build_error",
            "suggestion": "Space has a build error — contact the Space owner",
        }
    if "timed out" in full or "timeout" in full or "connection" in full:
        return {
            "error_type": "connection",
            "suggestion": "Could not connect to the Space — it may be down",
        }
    return {"error_type": "unknown", "suggestion": ""}


def _format_error(e: Exception) -> str:
    title = getattr(e, "title", None)
    message = getattr(e, "message", None) or str(e)
    classified = _classify_error(e)
    if classified.get("error_type") == "auth":
        message = "Authentication required"
        title = None
    err = {"error": message, **classified}
    if title:
        err["title"] = title
    return json.dumps(err)


def get_token(
    _data=None,
    request: Optional[Request] = None,
    token: Optional[OAuthToken] = None,
) -> str:
    """Return the HF token for this browser session. The host's locally saved
    token is only revealed to sessions holding the write token — share-link
    visitors and other remote clients get "" (logged-out experience)."""
    if token:
        return token.token
    if _request_has_write_token(request):
        return _get_locally_saved_hf_token() or ""
    return ""


def get_write_access(
    _data=None,
    request: Optional[Request] = None,
    token: Optional[OAuthToken] = None,
) -> str:
    return "true" if has_write_access(request, token) else "false"


def get_space_id(_data=None) -> str:
    """Return this Space's repo id (`owner/name`) for the "Save to Space" button.
    Empty locally — the button is hidden there anyway."""
    return os.getenv("SPACE_ID") or ""


def _workflow_key(workflow_file: str) -> str:
    """A stable identity for this workflow, used by the canvas to key the
    per-viewer layout and viewport it keeps in localStorage.

    The workflow's *name* can't do that job: it is editable from the canvas, and
    two unrelated workflows served from the same origin (same host and port, one
    after the other) can share it — so one workflow's arrangement would be
    applied to the other's nodes. What is needed is something stable across
    restarts and across edits to the graph: on a Space the repo id, and locally
    the graph file's path. The path is hashed rather than sent as-is so a
    viewer's browser storage doesn't carry the author's directory layout.
    """
    space = os.getenv("SPACE_ID")
    if space:
        return f"space:{space}"
    digest = hashlib.sha256(os.path.abspath(workflow_file).encode("utf-8")).hexdigest()
    return f"file:{digest[:16]}"


def get_oauth_available(_data=None) -> str:
    """True on a Space with `hf_oauth: true` (i.e. OAUTH_CLIENT_ID is set)."""
    return (
        "true"
        if get_space() is not None and bool(os.getenv("OAUTH_CLIENT_ID"))
        else "false"
    )


WORKFLOW_OAUTH_SCOPES: dict[str, str] = {
    "inference-api": "run nodes on the signed-in user's own inference quota",
    "write-repos": "save the workflow back to this Space",
}


def _missing_workflow_oauth_scopes() -> dict[str, str]:
    granted = set((os.getenv("OAUTH_SCOPES") or "").split())
    return {
        scope: why
        for scope, why in WORKFLOW_OAUTH_SCOPES.items()
        if scope not in granted
    }


def _warn_workflow_oauth_configuration() -> None:
    if get_space() is None:
        return
    if not os.getenv("OAUTH_CLIENT_ID"):
        warnings.warn(
            "Workflow OAuth is not enabled for this Space. Add `hf_oauth: true` "
            "to the README metadata so users can run workflows on their own "
            "inference quota.",
            UserWarning,
            stacklevel=3,
        )
        return

    missing = _missing_workflow_oauth_scopes()
    if not missing:
        return
    detail = ", ".join(f"`{scope}` (to {why})" for scope, why in missing.items())
    scopes = " and ".join(f"`{scope}`" for scope in missing)
    warnings.warn(
        f"Workflow OAuth is missing {detail}. Add {scopes} under "
        "`hf_oauth_scopes` in the README metadata and redeploy.",
        UserWarning,
        stacklevel=3,
    )


def get_oauth_scopes(_data=None) -> str:
    """Which of `WORKFLOW_OAUTH_SCOPES` the Space's OAuth app was granted, and
    which are missing. Empty off-Spaces and when OAuth is disabled."""
    if get_space() is None or not os.getenv("OAUTH_CLIENT_ID"):
        return json.dumps({"granted": [], "missing": {}})
    granted = (os.getenv("OAUTH_SCOPES") or "").split()
    return json.dumps(
        {
            "granted": granted,
            "missing": _missing_workflow_oauth_scopes(),
        }
    )


def call_space(
    data, request: Optional[Request] = None, token: Optional[OAuthToken] = None
) -> str:
    space_id = data[0] if data else ""
    try:
        endpoint = data[1] if len(data) > 1 else None
        args_json = data[2] if len(data) > 2 else "[]"
        hf_token = _resolve_token(data, 3, token, request)
        if not re.fullmatch(r"[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+", space_id or ""):
            return json.dumps(
                {
                    "error": "Invalid Space ID",
                    "error_type": "not_found",
                    "suggestion": "Space ID must be in owner/repo format",
                }
            )
        client = Client(space_id, token=hf_token)
        args = json.loads(args_json)
        if not endpoint or endpoint == "/predict":
            api_info = client.view_api(return_format="dict")
            named = list(
                (
                    api_info.get("named_endpoints", {})
                    if isinstance(api_info, dict)
                    else {}
                ).keys()
            )
            endpoint = (
                endpoint if endpoint in named else (named[0] if named else "/predict")
            )
        processed = []
        for arg in args:
            if isinstance(arg, dict) and ("url" in arg or "path" in arg):
                src = _sendable_ref(arg)
                processed.append(handle_file(src) if src else None)
            else:
                processed.append(arg)
        # The loop only sees top-level arguments, but the client uploads every
        # file-shaped dict it can reach, however deeply nested, and the caller
        # writes the `meta` marker that decides what counts (`process_input_files`
        # in `gradio_client/client.py`). So the same rule has to run over the
        # whole payload, against the client's own predicate.
        processed = client_utils.traverse(
            processed,
            lambda f: f if _sendable_ref(f) else None,
            client_utils.is_file_obj_with_meta,
        )
        while processed and processed[-1] is None:
            processed.pop()
        result = client.predict(*processed, api_name=endpoint)
        result = list(result) if isinstance(result, (list, tuple)) else [result]

        _tmpdir = os.path.realpath(tempfile.gettempdir())

        def process_item(item):
            if isinstance(item, dict):
                path = item.get("path") or item.get("value")
                if (
                    isinstance(path, str)
                    and os.path.realpath(path).startswith(_tmpdir)
                    and os.path.exists(path)
                ):
                    return {
                        "path": path,
                        "url": f"/gradio_api/file={client_utils.encode_file_path(path)}",
                        "is_file": True,
                    }
                return item
            if (
                isinstance(item, str)
                and os.path.realpath(item).startswith(_tmpdir)
                and os.path.exists(item)
            ):
                return {
                    "path": item,
                    "url": f"/gradio_api/file={client_utils.encode_file_path(item)}",
                    "is_file": True,
                }
            if isinstance(item, (list, tuple)):
                return [process_item(s) for s in item]
            return item

        return json.dumps([process_item(i) for i in result])
    except Exception as e:
        logger.error("call_space failed for %s: %s", space_id, e, exc_info=True)
        return _format_error(e)


_INFERENCE_ENDPOINT_SCHEMAS: dict[str, dict] = {
    "text_to_image": {
        "inputs": [
            {"id": "prompt", "label": "Prompt", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Image", "type": "image", "output_index": 0}
        ],
    },
    "text_to_speech": {
        "inputs": [
            {"id": "text", "label": "Text", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Audio", "type": "audio", "output_index": 0}
        ],
    },
    "text_to_video": {
        "inputs": [
            {"id": "prompt", "label": "Prompt", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Video", "type": "video", "output_index": 0}
        ],
    },
    "image_to_image": {
        "inputs": [
            {"id": "image", "label": "Image", "type": "image"},
            {"id": "prompt", "label": "Prompt", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Image", "type": "image", "output_index": 0}
        ],
    },
    "image_to_video": {
        "inputs": [
            {"id": "image", "label": "Image", "type": "image"},
            {"id": "prompt", "label": "Prompt", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Video", "type": "video", "output_index": 0}
        ],
    },
    "text_generation": {
        "inputs": [
            {"id": "prompt", "label": "Prompt", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Text", "type": "markdown", "output_index": 0}
        ],
    },
    "summarization": {
        "inputs": [
            {"id": "text", "label": "Text", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Summary", "type": "text", "output_index": 0}
        ],
    },
    "translation": {
        "inputs": [
            {"id": "text", "label": "Text", "type": "text"},
            {"id": "src_lang", "label": "Source Language", "type": "text"},
            {"id": "tgt_lang", "label": "Target Language", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Translation", "type": "text", "output_index": 0}
        ],
    },
    "fill_mask": {
        "inputs": [{"id": "text", "label": "Text", "type": "text"}],
        "outputs": [
            {"id": "out_0", "label": "Result", "type": "json", "output_index": 0}
        ],
    },
    "text_classification": {
        "inputs": [{"id": "text", "label": "Text", "type": "text"}],
        "outputs": [
            {"id": "out_0", "label": "Labels", "type": "json", "output_index": 0}
        ],
    },
    "token_classification": {
        "inputs": [{"id": "text", "label": "Text", "type": "text"}],
        "outputs": [
            {"id": "out_0", "label": "Entities", "type": "json", "output_index": 0}
        ],
    },
    "zero_shot_classification": {
        "inputs": [
            {"id": "text", "label": "Text", "type": "text"},
            {"id": "candidate_labels", "label": "Candidate Labels", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Scores", "type": "json", "output_index": 0}
        ],
    },
    "sentence_similarity": {
        "inputs": [
            {"id": "sentence", "label": "Sentence", "type": "text"},
            {"id": "other_sentences", "label": "Other Sentences", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Scores", "type": "json", "output_index": 0}
        ],
    },
    "question_answering": {
        "inputs": [
            {"id": "question", "label": "Question", "type": "text"},
            {"id": "context", "label": "Context", "type": "text"},
        ],
        "outputs": [
            {"id": "out_0", "label": "Answer", "type": "text", "output_index": 0}
        ],
    },
    "feature_extraction": {
        "inputs": [{"id": "text", "label": "Text", "type": "text"}],
        "outputs": [
            {"id": "out_0", "label": "Embeddings", "type": "json", "output_index": 0}
        ],
    },
    "image_classification": {
        "inputs": [{"id": "image", "label": "Image", "type": "image"}],
        "outputs": [
            {"id": "out_0", "label": "Labels", "type": "json", "output_index": 0}
        ],
    },
    "object_detection": {
        "inputs": [{"id": "image", "label": "Image", "type": "image"}],
        "outputs": [
            {"id": "out_0", "label": "Detections", "type": "json", "output_index": 0}
        ],
    },
    "image_segmentation": {
        "inputs": [{"id": "image", "label": "Image", "type": "image"}],
        "outputs": [
            {"id": "out_0", "label": "Segments", "type": "json", "output_index": 0}
        ],
    },
    "automatic_speech_recognition": {
        "inputs": [{"id": "audio", "label": "Audio", "type": "audio"}],
        "outputs": [
            {"id": "out_0", "label": "Text", "type": "text", "output_index": 0}
        ],
    },
    "audio_classification": {
        "inputs": [{"id": "audio", "label": "Audio", "type": "audio"}],
        "outputs": [
            {"id": "out_0", "label": "Labels", "type": "json", "output_index": 0}
        ],
    },
    # Vision-language models are served as `conversational`, so they're called
    # through chat completions rather than a task-specific endpoint. Port order
    # matches the canvas's image-text-to-text template (image, then prompt).
    "chat_completion": {
        "inputs": [
            {"id": "image", "label": "Image", "type": "image"},
            {"id": "text", "label": "Prompt", "type": "text"},
        ],
        # Chat models answer in prose that is very often markdown (headings,
        # lists, fenced code), so the tile renders it instead of showing the raw
        # asterisks. `markdown` wires interchangeably with `text`.
        "outputs": [
            {"id": "out_0", "label": "Answer", "type": "markdown", "output_index": 0}
        ],
    },
}


# Generous by default: vision-language models are asked to emit whole files
# (an HTML page, a long transcription), and reasoning models spend part of the
# budget before their first visible token — reasoning counts against this cap,
# and a dense screenshot can cost thousands of tokens before any output.
# Bounded by the canvas executor's 300s per-node timeout: at the ~100 tok/s
# these models stream, a larger cap would be cut off mid-answer anyway.
_CHAT_MAX_TOKENS = 16384


_ENDPOINT_OUTPUT_EXT: dict[str, str] = {
    "text_to_image": "png",
    "image_to_image": "png",
    "text_to_speech": "wav",
    "text_to_video": "mp4",
    "image_to_video": "mp4",
}


# Legacy pipeline tags (as sent by older saved workflows and the browser
# executor) → InferenceClient endpoint names. depth-estimation is absent on
# purpose: InferenceClient has no such method, so it keeps its raw-POST branch
# in call_model. Unmapped tags fall through to the chat/raw-POST fallback.
_PIPELINE_TAG_TO_ENDPOINT: dict[str, str] = {
    "text-generation": "text_generation",
    "text2text-generation": "text_generation",
    "conversational": "text_generation",
    "summarization": "summarization",
    "translation": "translation",
    "fill-mask": "fill_mask",
    "text-classification": "text_classification",
    "token-classification": "token_classification",
    "zero-shot-classification": "zero_shot_classification",
    "sentence-similarity": "sentence_similarity",
    "question-answering": "question_answering",
    "feature-extraction": "feature_extraction",
    "text-to-image": "text_to_image",
    "text-to-speech": "text_to_speech",
    "text-to-audio": "text_to_speech",
    "text-to-video": "text_to_video",
    "image-to-image": "image_to_image",
    "image-to-video": "image_to_video",
    "image-text-to-video": "image_to_video",
    "image-classification": "image_classification",
    "object-detection": "object_detection",
    "image-segmentation": "image_segmentation",
    "automatic-speech-recognition": "automatic_speech_recognition",
    "audio-classification": "audio_classification",
    "image-text-to-text": "chat_completion",
}


# Client params that expect a list of strings; port values arrive as a single
# string, split on the given pattern.
_ENDPOINT_LIST_KWARGS: dict[str, dict[str, str]] = {
    "zero_shot_classification": {"candidate_labels": r"[\n,]"},
    "sentence_similarity": {"other_sentences": r"\n"},
}


def get_model_endpoints(
    _data, _request: Optional[Request] = None, _token: Optional[OAuthToken] = None
) -> str:
    from huggingface_hub import InferenceClient

    # Only advertise endpoints the installed huggingface_hub can actually run,
    # so the UI never shapes a node around a method that would fail server-side.
    endpoints = [
        {"name": name, **schema}
        for name, schema in _INFERENCE_ENDPOINT_SCHEMAS.items()
        if getattr(InferenceClient, name, None) is not None
    ]
    return json.dumps(endpoints)


def _partition_params(fn, params: dict) -> dict:
    """Route *params* per fn's signature: extra_body / **kwargs / reject."""
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return dict(params)
    param_names = set(sig.parameters)
    accepts_kwargs = any(
        p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()
    )
    known: dict = {}
    unknown: dict = {}
    for k, v in params.items():
        (known if k in param_names else unknown)[k] = v
    if not unknown:
        return known
    if "extra_body" in param_names:
        known["extra_body"] = {**(known.get("extra_body") or {}), **unknown}
        return known
    if accepts_kwargs:
        known.update(unknown)
        return known
    raise ValueError(
        f"Model doesn't accept parameter(s): {', '.join(sorted(unknown))}. "
        "Remove those from the node or switch to a model that supports them."
    )


def _dispatch_model_endpoint(client, endpoint: str, kwargs: dict) -> str:
    """Call client.<endpoint>(**kwargs) and serialize the result."""
    fn = getattr(client, endpoint, None)
    if fn is None:
        import huggingface_hub

        raise ValueError(
            f"Task '{endpoint}' is not supported by the installed huggingface_hub "
            f"version ({huggingface_hub.__version__}). Upgrade it with "
            "`pip install -U huggingface_hub`."
        )
    schema_ids = [
        p["id"] for p in _INFERENCE_ENDPOINT_SCHEMAS.get(endpoint, {}).get("inputs", [])
    ]
    clean: dict = {}
    # Chat images are dereferenced by the provider, not locally, so they need a
    # different reference than the task endpoints, which hand the reference to
    # huggingface_hub and let it read the bytes off disk.
    to_url = _chat_image_url if endpoint == "chat_completion" else _sendable_ref
    for k, v in kwargs.items():
        if v is None or v == "":
            continue
        legacy = re.fullmatch(r"in_(\d+)", k)
        if legacy and k not in schema_ids and int(legacy.group(1)) < len(schema_ids):
            # positional port IDs from workflows saved before endpoint schemas
            k = schema_ids[int(legacy.group(1))]
        clean[k] = (
            to_url(v) if isinstance(v, dict) and ("url" in v or "path" in v) else v
        )
    for key, sep in _ENDPOINT_LIST_KWARGS.get(endpoint, {}).items():
        if isinstance(clean.get(key), str):
            clean[key] = [s.strip() for s in re.split(sep, clean[key]) if s.strip()]
    if endpoint == "zero_shot_classification" and not clean.get("candidate_labels"):
        # without labels, fall back to scoring with the model's own label set
        return _dispatch_model_endpoint(
            client, "text_classification", {"text": clean.get("text", "")}
        )
    if endpoint == "chat_completion":
        content = []
        if clean.get("text"):
            content.append({"type": "text", "text": clean["text"]})
        image_url = _chat_image_url(clean.get("image"))
        if image_url:
            content.append({"type": "image_url", "image_url": {"url": image_url}})
        if not content:
            raise ValueError("Connect a prompt or an image to this model.")
        extras = {k: v for k, v in clean.items() if k not in ("text", "image")}
        extras.setdefault("max_tokens", _CHAT_MAX_TOKENS)
        chat_params = _partition_params(client.chat_completion, extras)
        # Streamed, not buffered: the router's gateway times out a non-streaming
        # request at ~120s, which a vision model writing a whole file routinely
        # exceeds — reasoning alone can outlast it. Streaming keeps bytes moving,
        # so the request is bounded by the model, not by an idle proxy.
        parts: list[str] = []
        reasoned = 0
        finish_reason = None
        for chunk in client.chat_completion(
            [{"role": "user", "content": content}],
            stream=True,
            **chat_params,
        ):
            if not chunk.choices:
                continue
            choice = chunk.choices[0]
            delta = getattr(choice, "delta", None)
            if delta is not None:
                if delta.content:
                    parts.append(delta.content)
                reasoned += len(getattr(delta, "reasoning_content", None) or "")
            if choice.finish_reason:
                finish_reason = choice.finish_reason
        text = "".join(parts).strip()
        if not text:
            model_name = getattr(client, "model", None) or "The model"
            if finish_reason == "length":
                # Reasoning is billed against max_tokens, so a model can hit the
                # cap while still thinking and return no visible answer at all.
                raise ValueError(
                    f"{model_name} hit the {_CHAT_MAX_TOKENS}-token limit "
                    f"({reasoned} characters of reasoning) before producing an "
                    "answer. Simplify the prompt or use a smaller image, or "
                    "raise gradio.workflow._CHAT_MAX_TOKENS."
                )
            raise ValueError(
                f"{model_name} returned no text (finish_reason={finish_reason})."
            )
        return json.dumps([text])
    clean = _partition_params(fn, clean)
    if endpoint == "text_generation":
        clean.setdefault("max_new_tokens", 512)
        try:
            result = fn(**clean)
        except Exception as inner:
            msg = str(inner).lower()
            if "not supported" in msg and "conversational" in msg:
                r = client.chat_completion(
                    [{"role": "user", "content": clean.get("prompt", "")}],
                    max_tokens=512,
                )
                result = r.choices[0].message.content
            else:
                raise
    else:
        result = call_with_recovery(client, fn, clean)
    ext = _ENDPOINT_OUTPUT_EXT.get(endpoint)
    if ext:
        return json.dumps([_save_tmp(result, ext)])
    if isinstance(result, list) and result and hasattr(result[0], "answer"):
        # question-answering-style outputs: surface the top answer
        result = result[0]
    for attr in (
        "summary_text",
        "translation_text",
        "generated_text",
        "text",
        "answer",
    ):
        if hasattr(result, attr):
            return json.dumps([getattr(result, attr)])
    if isinstance(result, list):

        def _item(r):
            if hasattr(r, "__dict__"):
                return {k: v for k, v in vars(r).items() if not k.startswith("_")}
            return r

        return json.dumps(
            [[_item(r) for r in result]],
            default=lambda o: vars(o) if hasattr(o, "__dict__") else str(o),
        )
    if hasattr(result, "tolist"):
        return json.dumps([result.tolist()])
    return json.dumps(
        [result if isinstance(result, (str, int, float, bool)) else str(result)]
    )


def call_model(
    data, request: Optional[Request] = None, token: Optional[OAuthToken] = None
) -> str:
    model_id = data[0] if data else ""
    task = ""
    try:
        from huggingface_hub import InferenceClient

        if not re.fullmatch(r"[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+", model_id or ""):
            return json.dumps(
                {
                    "error": "Invalid model ID",
                    "error_type": "not_found",
                    "suggestion": "Model ID must be in owner/repo format",
                }
            )
        pipeline_tag = data[1] if len(data) > 1 else None
        args_json = data[2] if len(data) > 2 else "[]"
        hf_token = _resolve_token(data, 3, token, request)
        # "auto" lets HF route to whichever provider serves the model; pinning
        # "hf-inference" 404s for models not hosted there.
        provider = data[4] if len(data) > 4 and data[4] else "auto"
        client = InferenceClient(model=model_id, token=hf_token, provider=provider)
        args = json.loads(args_json)
        if isinstance(args, dict):
            endpoint = (
                _PIPELINE_TAG_TO_ENDPOINT.get(pipeline_tag or "") or pipeline_tag or ""
            )
            return _dispatch_model_endpoint(client, endpoint, args)

        task = pipeline_tag or "text-generation"
        a0 = args[0] if args else ""
        a1 = args[1] if len(args) > 1 else ""

        if task == "depth-estimation":
            headers = {"Authorization": f"Bearer {hf_token}"} if hf_token else {}
            resp = httpx.post(
                f"https://api-inference.huggingface.co/models/{model_id}",
                headers=headers,
                json={"inputs": _sendable_ref(a0)},
                timeout=60,
            )
            resp.raise_for_status()
            import io as _io

            from PIL import Image as _Image

            depth_img = _Image.open(_io.BytesIO(resp.content))
            return json.dumps([_save_tmp(depth_img, "png")])

        endpoint = _PIPELINE_TAG_TO_ENDPOINT.get(task)
        if endpoint:
            # Positional args from legacy saved workflows and the browser
            # executor map onto the endpoint schema's input order.
            schema_inputs = _INFERENCE_ENDPOINT_SCHEMAS[endpoint]["inputs"]
            kwargs = {
                schema_inputs[i]["id"]: val
                for i, val in enumerate(args[: len(schema_inputs)])
            }
            return _dispatch_model_endpoint(client, endpoint, kwargs)

        def _resolve(v):
            return (
                _sendable_ref(v)
                if isinstance(v, dict) and ("url" in v or "path" in v)
                else v
            )

        a1_missing = a1 is None or a1 == ""
        payload = _resolve(a0) if a1_missing else [_resolve(a0), _resolve(a1)]
        headers = {"Authorization": f"Bearer {hf_token}"} if hf_token else {}
        fallback_resp = httpx.post(
            f"https://api-inference.huggingface.co/models/{model_id}",
            headers=headers,
            json={"inputs": payload},
            timeout=60,
        )
        fallback_resp.raise_for_status()
        try:
            parsed = fallback_resp.json()
        except Exception:
            parsed = fallback_resp.text
        return json.dumps([parsed])
    except Exception as e:
        logger.error(
            "call_model failed for %s (task=%s): %s",
            model_id,
            task,
            e,
            exc_info=True,
        )
        return _format_error(e)


def fetch_dataset(
    data, request: Optional[Request] = None, token: Optional[OAuthToken] = None
) -> str:
    try:
        dataset_id = data[0]
        config = data[1] if len(data) > 1 and data[1] else "default"
        split = data[2] if len(data) > 2 and data[2] else "train"
        offset = int(data[3]) if len(data) > 3 and data[3] else 0
        length = int(data[4]) if len(data) > 4 and data[4] else 10
        hf_token = _resolve_token(data, 5, token, request)
        params = urllib.parse.urlencode(
            {
                "dataset": dataset_id,
                "config": config,
                "split": split,
                "offset": offset,
                "length": min(length, 100),
            }
        )
        result = json.loads(
            _hf_request(
                f"https://datasets-server.huggingface.co/rows?{params}",
                hf_token,
                timeout=30,
            )
        )
        return json.dumps(
            {
                "features": result.get("features", []),
                "rows": [r.get("row", {}) for r in result.get("rows", [])],
                "num_rows_total": result.get("num_rows_total", 0),
            }
        )
    except Exception as e:
        logger.error(
            "fetch_dataset failed for %s: %s",
            data[0] if data else "",
            e,
            exc_info=True,
        )
        return json.dumps({"error": str(e), "error_type": "unknown", "suggestion": ""})


def _curated_entry_to_space_result(entry: dict) -> dict:
    return {
        "id": entry.get("id"),
        "likes": 0,
        "trendingScore": (entry.get("validation") or {}).get("latency_ms") or 0,
        "runtime": {"stage": "RUNNING"},
        "pipeline_tag": entry.get("task"),
        "tags": ["zero-gpu"] if entry.get("zero_gpu") else [],
        "cardData": {
            "title": entry.get("title"),
            "short_description": entry.get("description"),
            "tags": ["zero-gpu"] if entry.get("zero_gpu") else [],
            "sdk": "gradio",
        },
        "_curated": True,
        "_featured": bool(entry.get("featured")),
        "_thumbnail": entry.get("thumbnail"),
    }


def _curated_entry_to_model_result(entry: dict) -> dict:
    return {
        "id": entry.get("id"),
        "likes": 0,
        "downloads": 0,
        "pipeline_tag": entry.get("task"),
        "_curated": True,
        "_featured": bool(entry.get("featured")),
        "_thumbnail": entry.get("thumbnail"),
    }


def _filter_curated(
    items: list[dict],
    kind_filter: str,
    task: str,
    query: str,
    modality: str = "",
) -> list[dict]:
    out: list[dict] = []
    q = query.lower().strip()
    for entry in items:
        if entry.get("kind") != kind_filter:
            continue
        v = entry.get("validation") or {}
        status = v.get("status", "ok")
        if status and status != "ok":
            continue
        if task:
            if entry.get("task") != task and entry.get("space_category") != task:
                continue
        elif modality and entry.get("modality") != modality:
            continue
        if q:
            haystack = " ".join(
                [
                    str(entry.get("title") or ""),
                    str(entry.get("description") or ""),
                    str(entry.get("id") or ""),
                ]
            ).lower()
            if q not in haystack:
                continue
        out.append(entry)
    return out


def search_spaces(
    data, _request: Optional[Request] = None, _token: Optional[OAuthToken] = None
) -> str:
    kind = data[0] if data else "trending"
    try:
        query = data[1] if len(data) > 1 and data[1] else ""
        space_tag = data[2] if len(data) > 2 and data[2] else ""
        modality = data[3] if len(data) > 3 and isinstance(data[3], str) else ""
        zero_gpu_only = bool(data[4]) if len(data) > 4 else False

        items = _filter_curated(_load_curated(), "space", space_tag, query, modality)
        if zero_gpu_only:
            items = [e for e in items if e.get("zero_gpu")]

        if kind == "new":
            items.sort(key=lambda e: e.get("added_at") or "", reverse=True)
        else:

            def _rank(e: dict) -> tuple:
                v = e.get("validation") or {}
                return (
                    0 if e.get("zero_gpu") else 1,
                    0 if e.get("featured") else 1,
                    v.get("latency_ms") or 999_999,
                    e.get("added_at") or "",
                )

            items.sort(key=_rank)

        normalized = [_curated_entry_to_space_result(e) for e in items[:48]]
        return json.dumps(normalized)
    except Exception as e:
        logger.error("search_spaces failed (kind=%s): %s", kind, e, exc_info=True)
        return json.dumps({"error": str(e)})


def search_models(
    data, _request: Optional[Request] = None, _token: Optional[OAuthToken] = None
) -> str:
    kind = data[0] if data else "trending"
    try:
        query = data[1] if len(data) > 1 and data[1] else ""
        pipeline_tag = data[2] if len(data) > 2 and data[2] else ""
        modality = data[3] if len(data) > 3 and isinstance(data[3], str) else ""

        items = _filter_curated(_load_curated(), "model", pipeline_tag, query, modality)

        if kind == "new":
            items.sort(key=lambda e: e.get("added_at") or "", reverse=True)
        else:
            items.sort(
                key=lambda e: (0 if e.get("featured") else 1, e.get("added_at") or "")
            )

        normalized = [_curated_entry_to_model_result(e) for e in items[:48]]
        return json.dumps(normalized)
    except Exception as e:
        logger.error("search_models failed (kind=%s): %s", kind, e, exc_info=True)
        return json.dumps({"error": str(e)})


def curated_modalities(_data=None, _token: Optional[OAuthToken] = None) -> str:
    try:
        items = _load_curated()
        mods: set[str] = set()
        for entry in items:
            v = entry.get("validation") or {}
            if v.get("status", "ok") != "ok":
                continue
            m = entry.get("modality")
            if m:
                mods.add(m)
        return json.dumps(sorted(mods))
    except Exception as e:
        logger.error("curated_modalities failed: %s", e, exc_info=True)
        return json.dumps({"error": str(e)})


def curated_modality_tasks(data, _token: Optional[OAuthToken] = None) -> str:
    try:
        modality = (data[0] if data else "") or ""
        items = _load_curated()
        tasks: set[str] = set()
        for entry in items:
            if modality and entry.get("modality") != modality:
                continue
            v = entry.get("validation") or {}
            if v.get("status", "ok") != "ok":
                continue
            t = entry.get("task")
            sc = entry.get("space_category")
            if t:
                tasks.add(t)
            if sc:
                tasks.add(sc)
        return json.dumps(sorted(tasks))
    except Exception as e:
        logger.error("curated_modality_tasks failed: %s", e, exc_info=True)
        return json.dumps({"error": str(e)})


def is_curated(data, _token: Optional[OAuthToken] = None) -> str:
    try:
        repo_id = (data[0] if data else "") or ""
        kind = (data[1] if len(data) > 1 else "") or ""
        items = _load_curated()
        for entry in items:
            if entry.get("id") != repo_id:
                continue
            if kind and entry.get("kind") != kind:
                continue
            v = entry.get("validation") or {}
            if v.get("status", "ok") != "ok":
                return json.dumps({"curated": False})
            return json.dumps(
                {
                    "curated": True,
                    "status": "ok",
                    "featured": bool(entry.get("featured")),
                }
            )
        return json.dumps({"curated": False})
    except Exception as e:
        logger.error("is_curated failed: %s", e, exc_info=True)
        return json.dumps({"error": str(e)})


_QUICKSEARCH_CACHE: dict[str, tuple[float, str]] = {}
_QUICKSEARCH_TTL = 30.0


def search_quick(
    data,
    request: Request | None = None,
    token: Optional[OAuthToken] = None,
) -> str:
    import time

    query = data[0] if data and data[0] else ""
    if not query or len(query) < 2:
        return json.dumps({"spaces": [], "models": []})
    try:
        hf_token = _resolve_token(data, 1, token, request)

        cache_key = query.lower().strip()
        now = time.monotonic()
        cached = _QUICKSEARCH_CACHE.get(cache_key)
        if cached and cached[0] > now:
            return cached[1]

        def _one(repo_type: str) -> list:
            url = (
                "https://huggingface.co/api/quicksearch?"
                f"q={urllib.parse.quote(query)}&type={repo_type}&limit=8"
            )
            try:
                raw = _hf_request(url, hf_token)
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    return parsed.get(f"{repo_type}s") or parsed.get(repo_type) or []
                if isinstance(parsed, list):
                    return parsed
                return []
            except Exception:
                return []

        space_future = _SEARCH_POOL.submit(_one, "space")
        model_future = _SEARCH_POOL.submit(_one, "model")
        spaces = space_future.result()
        models = model_future.result()

        payload = json.dumps({"spaces": spaces, "models": models})
        _QUICKSEARCH_CACHE[cache_key] = (now + _QUICKSEARCH_TTL, payload)
        if len(_QUICKSEARCH_CACHE) > 256:
            for k in list(_QUICKSEARCH_CACHE.keys())[:64]:
                _QUICKSEARCH_CACHE.pop(k, None)
        return payload
    except Exception as e:
        logger.error("search_quick failed (q=%s): %s", query, e, exc_info=True)
        return json.dumps({"error": str(e)})


_REPO_ID_RE = re.compile(r"^[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+$")


def _parse_repo_input(raw: str) -> tuple[str, Optional[str]]:
    s = (raw or "").strip().rstrip("/")
    if not s:
        return "", None
    if _REPO_ID_RE.match(s):
        return s, None
    s = re.sub(r"^https?://(?:www\.)?", "", s)
    s = re.sub(r"^hf\.co/", "huggingface.co/", s)
    m = re.match(
        r"^huggingface\.co/(spaces|datasets|models)?/?([^/\s?#]+)/([^/\s?#]+)",
        s,
    )
    if m:
        section, org, name = m.group(1), m.group(2), m.group(3)
        if section == "spaces":
            return f"{org}/{name}", "space"
        if section == "datasets":
            return f"{org}/{name}", "dataset"
        return f"{org}/{name}", "model" if section else None
    return "", None


def resolve_repo(
    data,
    request: Request | None = None,
    token: Optional[OAuthToken] = None,
) -> str:
    raw = data[0] if data else ""
    try:
        hf_token = _resolve_token(data, 1, token, request)
        repo_id, kind_hint = _parse_repo_input(raw)

        def _try(rid: str, repo_type: str) -> Optional[dict]:
            try:
                url = (
                    f"https://huggingface.co/api/{repo_type}s/"
                    f"{urllib.parse.quote(rid, safe='/')}"
                )
                return json.loads(_hf_request(url, hf_token))
            except Exception:
                return None

        if not repo_id:
            sub = re.match(
                r"^(?:https?://)?([^/]+)\.hf\.space", raw.strip(), re.IGNORECASE
            )
            if sub:
                parts = sub.group(1).split("-")
                for i in range(1, len(parts)):
                    candidate = f"{'-'.join(parts[:i])}/{'-'.join(parts[i:])}"
                    rec = _try(candidate, "space")
                    if rec and rec.get("id"):
                        return json.dumps(
                            {"kind": "space", "id": rec["id"], "record": rec}
                        )
            return json.dumps({"error": "not_a_repo"})

        repo_types: list[str] = (
            [kind_hint]
            if kind_hint in ("space", "model", "dataset")
            else ["space", "model"]
        )
        for repo_type in repo_types:
            rec = _try(repo_id, repo_type)
            if rec and rec.get("id"):
                return json.dumps({"kind": repo_type, "id": rec["id"], "record": rec})
        return json.dumps({"error": "not_found", "id": repo_id})
    except Exception as e:
        logger.error("resolve_repo failed (raw=%s): %s", raw, e, exc_info=True)
        return json.dumps({"error": str(e)})


def search_datasets(
    data, request: Optional[Request] = None, token: Optional[OAuthToken] = None
) -> str:
    query = data[0] if data else ""
    try:
        hf_token = _resolve_token(data, 1, token, request)
        search_param = f"search={urllib.parse.quote(query)}&" if query else ""
        url = f"https://huggingface.co/api/datasets?{search_param}sort=likes&direction=-1&limit=20"
        return _hf_request(url, hf_token)
    except Exception as e:
        logger.error("search_datasets failed (query=%s): %s", query, e, exc_info=True)
        return json.dumps({"error": str(e)})


def get_dataset_schema(
    data, request: Optional[Request] = None, token: Optional[OAuthToken] = None
) -> str:
    dataset_id = data[0] if data else ""
    try:
        hf_token = _resolve_token(data, 1, token, request)
        try:
            splits_data = json.loads(
                _hf_request(
                    f"https://datasets-server.huggingface.co/splits?dataset={urllib.parse.quote(dataset_id)}",
                    hf_token,
                    timeout=30,
                )
            )
        except Exception as exc:
            raise Exception(
                "Could not load dataset — it may not be viewer-compatible"
            ) from exc
        splits = splits_data.get("splits", [])
        if not splits:
            raise Exception("No available splits found for this dataset")
        picked = next((s for s in splits if s["split"] == "train"), splits[0])
        try:
            rows_data = json.loads(
                _hf_request(
                    "https://datasets-server.huggingface.co/first-rows?"
                    + urllib.parse.urlencode(
                        {
                            "dataset": dataset_id,
                            "config": picked["config"],
                            "split": picked["split"],
                        }
                    ),
                    hf_token,
                    timeout=30,
                )
            )
        except Exception as exc:
            raise Exception(
                "Could not load dataset — it may not be viewer-compatible"
            ) from exc
        return json.dumps(
            {
                "config": picked["config"],
                "split": picked["split"],
                "features": rows_data.get("features", []),
            }
        )
    except Exception as e:
        logger.error(
            "get_dataset_schema failed for %s: %s", dataset_id, e, exc_info=True
        )
        return json.dumps({"error": str(e)})


# elem_id of the column holding the app view; the canvas frontend looks it up to
# mark it inert while the canvas covers it.
_APP_ELEM_ID = "workflow-app"
# The row gives each child a 0% flex-basis, which overrides the scale=0
# button's `width: fit-content` and squeezes it down to its padding.
_APP_CSS = f"""
#{_APP_ELEM_ID}-header {{ justify-content: flex-end; }}
#{_APP_ELEM_ID}-header > button {{ flex: none; }}
"""


class Workflow(Blocks):
    """
    Build and launch a visual AI workflow as a Gradio app.

    Reads a workflow topology from a JSON file and optionally binds Python functions
    that can be used as nodes in the workflow.

    Example:
        ```python
        from gradio import Workflow

        def summarize(text: str) -> str:
            return text[:200]

        Workflow(graph="workflow.json", bind={"summarize": summarize}).launch()
        ```

    The graph file uses schema version 2 and defines references, operators,
    subjects, and edges:
        ```json
        {
          "schema_version": "2",
          "references": [
            {
              "id": "prompt", "role": "reference", "label": "Prompt",
              "asset_type": "text",
              "inputs": [{"id": "in", "label": "Text", "type": "text"}],
              "outputs": [{"id": "out", "label": "Text", "type": "text"}],
              "data": {"out": "A sunset over the ocean"}
            }
          ],
          "operators": [
            {
              "id": "image", "role": "operator", "kind": "model",
              "model_id": "black-forest-labs/FLUX.1-schnell",
              "pipeline_tag": "text-to-image", "endpoint": "text_to_image",
              "inputs": [{"id": "prompt", "label": "Prompt", "type": "text", "required": true}],
              "outputs": [{"id": "out_0", "label": "Image", "type": "image", "output_index": 0}],
              "data": {}
            }
          ],
          "subjects": [
            {
              "id": "result", "role": "subject", "label": "Image",
              "asset_type": "image",
              "inputs": [{"id": "in", "label": "Image", "type": "image"}],
              "outputs": [{"id": "out", "label": "Image", "type": "image"}],
              "data": {}
            }
          ],
          "edges": [
            {"id": "e1", "from_node_id": "prompt", "from_port_id": "out", "to_node_id": "image", "to_port_id": "prompt", "type": "text"},
            {"id": "e2", "from_node_id": "image", "from_port_id": "out_0", "to_node_id": "result", "to_port_id": "in", "type": "image"}
          ]
        }
        ```
    """

    def __init__(
        self,
        graph: str | None = None,
        *,
        bind: dict[str, Callable] | list[Callable] | None = None,
        edges: list[tuple[str, str]] | None = None,
    ):
        """
        Parameters:
            graph: Path to the workflow JSON file describing the canvas graph
                (nodes + edges). Relative paths are resolved from the directory
                containing the calling script. Defaults to `workflow.json` in
                that directory. The file is created on first save if it doesn't
                exist.
            bind: Functions callable from the canvas frontend via the `call_fn` server
                function. Pass a list of callables (keys default to ``fn.__name__``) or
                a dict mapping explicit names to callables.
            edges: List of ``(from_endpoint, to_endpoint)`` tuples that wire nodes
                together when generating a workflow from ``bind`` (ignored when an
                existing ``graph`` file is loaded). Each endpoint is either
                ``"fn_name"`` (uses the first available port) or
                ``"fn_name.port_label"`` to target a specific port.

                Example::

                    edges=[
                        ("shout", "reverse"),         # first output → first input
                        ("clean.output", "tag.text"), # by port label
                    ]
        """
        if graph is None or not os.path.isabs(graph):
            caller_filename = sys._getframe(1).f_code.co_filename
            caller_dir = os.path.dirname(os.path.abspath(caller_filename))
            graph = os.path.join(
                caller_dir, "workflow.json" if graph is None else graph
            )

        if isinstance(bind, list):
            bind = {getattr(fn, "__name__", repr(fn)): fn for fn in bind}

        self._workflow_file = graph
        self._workflow_name = (
            os.path.splitext(os.path.basename(graph))[0]
            .replace("_", " ")
            .replace("-", " ")
            .title()
        )
        self._bound: dict[str, Callable] = bind or {}
        self._edges: list[tuple[str, str]] = edges or []

        if Context.root_block is not None:
            raise ValueError(
                "gr.Workflow cannot be created inside another gr.Blocks context."
            )

        warnings.warn(
            "gr.Workflow is currently in beta. Its API and UX may change in future releases.",
            UserWarning,
        )
        _warn_workflow_oauth_configuration()

        super().__init__(mode="workflow")
        self._build()

    def _build(self):
        # Set once the API endpoints are registered (post UI build); save_workflow
        # re-syncs it so /info + /call track edits to the graph.
        self._api_endpoints: WorkflowEndpointManager | None = None
        self._canvas: WorkflowCanvas | None = None

        if self._edges and os.path.exists(self._workflow_file):
            logger.warning(
                "Workflow: edges= is ignored because '%s' already exists. "
                "Delete the file to regenerate the workflow from bind/edges.",
                self._workflow_file,
            )

        # Callable so each browser session re-reads `workflow.json`, picking up
        # writes from `save_workflow` instead of the construction-time snapshot.
        def _load_initial() -> str | None:
            try:
                with open(self._workflow_file, encoding="utf-8") as f:
                    return f.read()
            except FileNotFoundError:
                if self._bound:
                    return _workflow_from_bind(
                        self._bound, self._edges, name=self._workflow_name
                    )
                return None

        bound = self._bound
        _save_lock = threading.Lock()

        def call_fn(
            data, request: Optional[Request] = None, token: Optional[OAuthToken] = None
        ) -> str:
            fn_name = data[0] if data else ""
            try:
                args_json = data[1] if len(data) > 1 else "[]"
                fn = bound.get(fn_name)
                if fn is None:
                    return json.dumps(
                        {
                            "error": f"No function '{fn_name}' bound to this workflow",
                            "error_type": "unknown",
                            "suggestion": "Check the bind= argument to Workflow()",
                        }
                    )
                args = json.loads(args_json)
                if not isinstance(args, list):
                    args = [args]
                args, *_ = _special_args(fn, args, request, None, token=token)
                if inspect.iscoroutinefunction(fn):
                    import asyncio

                    result = asyncio.run(fn(*args))
                else:
                    result = fn(*args)
                out = list(result) if isinstance(result, (list, tuple)) else [result]
                return json.dumps(out)
            except Exception as e:
                logger.error("call_fn failed for %s: %s", fn_name, e, exc_info=True)
                return json.dumps(
                    {"error": str(e), "error_type": "unknown", "suggestion": ""}
                )

        workflow_file = self._workflow_file

        _max_workflow_bytes = 5 * 1024 * 1024

        def list_bound_fns(_data=None, _token: Optional[OAuthToken] = None) -> str:
            """Return the bound functions' signatures so the canvas can offer
            them as add-able nodes via a dedicated bottom-bar button. The
            output port shape mirrors `_workflow_from_bind` so re-adding a
            previously-deleted node produces an identical template.
            """
            templates = []
            for fn_name, fn in bound.items():
                try:
                    sig = inspect.signature(fn)
                except (ValueError, TypeError):
                    sig = inspect.Signature()
                try:
                    _hints = get_type_hints(fn)
                except Exception:
                    _hints = getattr(fn, "__annotations__", {})
                inputs = [
                    {
                        "id": f"in_{p}",
                        "label": p,
                        "type": _PY_TO_PORT.get(param.annotation, "text"),
                    }
                    for p, param in sig.parameters.items()
                    if p != "self" and not _is_injected_param(_hints.get(p))
                ]
                if not inputs:
                    inputs = [{"id": "in_0", "label": "input", "type": "text"}]
                outputs = [
                    {
                        "id": "out_0",
                        "label": "output",
                        "type": _PY_TO_PORT.get(sig.return_annotation, "text"),
                    }
                ]
                templates.append(
                    {
                        "fn": fn_name,
                        "label": fn_name,
                        "inputs": inputs,
                        "outputs": outputs,
                    }
                )
            return json.dumps(templates)

        def get_workflow_api(_data=None, _request: Optional[Request] = None) -> str:
            """Describe the workflow's API endpoints (one per subgraph) for the
            frontend "View API" panel. Re-reads the current graph so it tracks
            live edits, same as the registered endpoints."""
            from gradio.workflow_api import WorkflowGraph, describe_workflow_api

            graph = WorkflowGraph.from_json(_load_initial())
            endpoints = describe_workflow_api(graph) if graph is not None else []
            return json.dumps({"endpoints": endpoints})

        def _publish_saved_value(payload: str) -> None:
            """Make pages opened from now on load `payload`. The canvas's value
            was computed once, at launch, and that copy is what `/config` (and
            the HTML page) hands to the canvas — which loads the first value it
            gets, so without this it would open on the launch-time graph and
            could later save it back over newer edits."""
            canvas = self._canvas
            if canvas is None:
                return
            canvas.value = payload
            config = getattr(self, "config", None) or {}
            for component in config.get("components", []):
                if component.get("id") == canvas._id:
                    component.setdefault("props", {})["value"] = payload
                    break

        def save_workflow(
            data,
            request: Optional[Request] = None,
            token: Optional[OAuthToken] = None,
        ) -> str:
            if not has_write_access(request, token):
                return json.dumps(
                    {
                        "error": "Write access required to save this workflow",
                        "error_type": "auth",
                        "suggestion": "Open the app via the write-access link "
                        "printed at launch (or sign in as the Space owner)",
                    }
                )
            try:
                payload = data[0] if isinstance(data, list) and data else str(data)
                if len(payload.encode()) > _max_workflow_bytes:
                    return json.dumps({"error": "Workflow payload exceeds 5 MB limit"})
                try:
                    parsed = json.loads(payload)
                except json.JSONDecodeError as exc:
                    return json.dumps({"error": f"Invalid workflow JSON: {exc}"})
                if not isinstance(parsed, dict) or parsed.get("schema_version") != "2":
                    return json.dumps(
                        {"error": "Workflow payload must use schema_version 2"}
                    )
                try:
                    from gradio.workflow_api import WorkflowGraph

                    WorkflowGraph(parsed)
                except ValueError as exc:
                    return json.dumps({"error": f"Invalid workflow schema: {exc}"})
                with _save_lock:
                    with open(workflow_file, "w", encoding="utf-8") as f:
                        f.write(payload)
                    _publish_saved_value(payload)
                    if self._api_endpoints is not None:
                        try:
                            self._api_endpoints.sync()
                        except Exception:
                            logger.error(
                                "Workflow: endpoint sync after save failed",
                                exc_info=True,
                            )
                return "ok"
            except Exception as e:
                logger.error("save_workflow failed: %s", e, exc_info=True)
                return json.dumps({"error": str(e)})

        def get_workflow_key(_data=None) -> str:
            return _workflow_key(workflow_file)

        def get_app_version(_data=None) -> str:
            """`<structure>.<defaults>`: the first part is bumped whenever a save
            rebuilds the app view / endpoints (an open page's event ids no
            longer exist), the second when a save only changes the pre-filled
            values. Either way the frontend's copy of the app is stale."""
            manager = self._api_endpoints
            if manager is None:
                return "0.0"
            return f"{manager.version}.{manager.defaults_version}"

        async def record_workflow_run(
            data,
            request: Optional[Request] = None,
        ) -> str:
            """Record a completed canvas run."""
            from gradio import history

            try:
                bucket_id = data[0] if data else ""
                endpoint_label = data[1] if len(data) > 1 else "workflow"
                inputs = data[2] if len(data) > 2 else {}
                outputs = data[3] if len(data) > 3 else {}
                if not isinstance(inputs, dict) or not isinstance(outputs, dict):
                    return json.dumps({"error": "Malformed run payload"})

                app = history.app_from_request(request)
                if app is None:
                    return json.dumps({"error": "No server app for this request"})

                endpoint = history.endpoint_key(str(endpoint_label), None)

                record = await history.record_run(
                    app,
                    request=request,
                    inputs=inputs,
                    outputs=outputs,
                    endpoint=endpoint,
                    bucket_id=bucket_id or None,
                )
                if record is None:
                    return json.dumps(
                        {
                            "error": "History is not available — sign in with "
                            "Hugging Face and connect a bucket first.",
                            "error_type": "auth",
                        }
                    )
                return json.dumps({"record": dataclasses.asdict(record)})
            except Exception as e:
                logger.error("record_workflow_run failed: %s", e, exc_info=True)
                return json.dumps({"error": str(e)})

        server_functions = [
            get_token,
            get_write_access,
            get_oauth_available,
            get_oauth_scopes,
            get_space_id,
            get_workflow_key,
            get_app_version,
            record_workflow_run,
            call_space,
            call_model,
            fetch_dataset,
            search_spaces,
            search_models,
            search_datasets,
            search_quick,
            resolve_repo,
            is_curated,
            curated_modalities,
            curated_modality_tasks,
            get_dataset_schema,
            list_bound_fns,
            get_workflow_api,
            get_model_endpoints,
            save_workflow,
        ]

        from gradio.workflow_api import WorkflowGraph, register_workflow_endpoints

        # Operator-kind → server-function used to execute that node. The same
        # functions back the canvas's client-side run; the API executor reuses
        # them (with request/token threaded for token resolution).
        callers = {
            "space": call_space,
            "model": call_model,
            "fn": call_fn,
            "dataset": fetch_dataset,
        }

        def _current_graph() -> WorkflowGraph | None:
            return WorkflowGraph.from_json(_load_initial())

        with self:
            self._canvas = WorkflowCanvas(
                value=_load_initial,
                server_functions=server_functions,
                app_view=_APP_ELEM_ID,
            )
            # The "app view": a regular Gradio app built from the same
            # components that back the workflow's API endpoints (filled in by
            # `register_workflow_endpoints` below). The canvas overlays it; the
            # frontend decides which one a visitor sees.
            with gr.Column(elem_id=_APP_ELEM_ID) as app_root:
                if get_space() is not None and os.getenv("OAUTH_CLIENT_ID"):
                    # Created here rather than by the endpoint manager: the
                    # button attaches a load event, which only a regular
                    # `with Blocks` context wires up.
                    with gr.Row(elem_id=f"{_APP_ELEM_ID}-header"):
                        gr.LoginButton(size="sm", scale=0, min_width=0)

        def _wrap_bound_fn(fn: Callable) -> Callable:
            async def wrapper(
                args_json: str,
                _request: Optional[Request] = None,
                _token: Optional[OAuthToken] = None,
            ) -> str:
                args = json.loads(args_json)
                if not isinstance(args, list):
                    args = [args]
                args, *_ = _special_args(fn, args, _request, None, token=_token)
                try:
                    result = (
                        await fn(*args)
                        if inspect.iscoroutinefunction(fn)
                        else await anyio.to_thread.run_sync(
                            lambda: fn(*args), limiter=self.limiter
                        )
                    )
                except Exception as e:
                    raise gr.Error(str(e)) from e
                out = list(result) if isinstance(result, (list, tuple)) else [result]
                return json.dumps(out)

            return wrapper

        if bound:
            from gradio.workflow_api import _active_blocks

            if len(bound) != len({_SANITIZE_RE.sub("_", n) for n in bound}):
                sanitized = [_SANITIZE_RE.sub("_", n) for n in bound]
                dupes = {s for s in sanitized if sanitized.count(s) > 1}
                raise ValueError(
                    f"gr.Workflow: bound function names produce duplicate endpoint "
                    f"names after sanitizing: {dupes}. Rename one."
                )

            with _active_blocks(self):
                for fn_name, fn in bound.items():
                    sanitized_name = _SANITIZE_RE.sub("_", fn_name)
                    gr.api(
                        _wrap_bound_fn(fn),
                        api_name=f"predict_fn_{sanitized_name}",
                        concurrency_limit="default",
                        api_visibility="undocumented",
                    )
        # Expose each subject (output) as a named API endpoint reusing /info +
        # /call. The manager re-syncs on every save_workflow, so adding,
        # removing, renaming, or retyping an output updates the live API.
        self._api_endpoints = register_workflow_endpoints(
            self, _current_graph, callers, app_root=app_root
        )

    def launch(self, *args, **kwargs):  # type: ignore[override]
        """Launch the workflow as a Gradio app. Accepts the same arguments as `gr.Blocks.launch()`.
        `call_space` / `_save_tmp` write inference outputs to the system tempdir
        and serve them back as `/gradio_api/file=…` URLs; the tempdir is added
        to `allowed_paths` so those URLs resolve.

        Locally, editing requires the write token: the full edit link is printed
        after the standard launch output, and — unless `inbrowser` is passed
        explicitly — opened in a browser tab automatically (like `jupyter
        notebook` does with its token URL). Plain local/share URLs open the app
        read-only. See `_should_auto_open_browser` for when the tab is opened."""
        if args:
            names = list(inspect.signature(super().launch).parameters)
            kwargs.update(dict(zip(names, args)))
        kwargs["allowed_paths"] = [
            tempfile.gettempdir(),
            *(kwargs.get("allowed_paths") or []),
        ]
        kwargs["css"] = _APP_CSS + (kwargs.get("css") or "")
        # We need the edit link to print (and the browser to open to it) before
        # the main thread is blocked, which means super().launch() must return
        # first. Rather than forcing `debug=False` — which would also strip
        # `debug` from `create_app()` (FastAPI error display) and the Colab
        # error-printing messages — we pass `debug` through unchanged and simply
        # neutralize `block_thread` for the duration of the inner launch, then
        # replicate Blocks.launch()'s blocking behavior ourselves below.
        prevent_thread_lock = bool(kwargs.get("prevent_thread_lock", False))
        debug = bool(kwargs.get("debug", False))
        # `inbrowser` defaults to opening the write-access link, but only when
        # the caller didn't say either way — an explicit `inbrowser=False` still
        # means "don't open anything".
        explicit_inbrowser = kwargs.get("inbrowser")
        inbrowser = (
            bool(explicit_inbrowser)
            if explicit_inbrowser is not None
            else _should_auto_open_browser()
        )
        kwargs["inbrowser"] = False

        real_block_thread = self.block_thread
        self.block_thread = lambda: None  # type: ignore[method-assign]
        try:
            launch_result = super().launch(**kwargs)
        finally:
            self.block_thread = real_block_thread  # type: ignore[method-assign]
        _, local_url, share_url = launch_result

        write_url = None
        if get_space() is None and local_url:
            sep = "&" if "?" in local_url else "?"
            write_url = f"{local_url}{sep}write_token={WRITE_TOKEN}"
            if not kwargs.get("quiet", False):
                opening = " — opening it in your browser" if inbrowser else ""
                print(
                    f"\n* Workflow write-access link (keep private as it lets you edit the workflow that all users see){opening}: {write_url}"
                )
        if inbrowser:
            webbrowser.open(
                write_url or (share_url if self.share and share_url else local_url)
            )

        is_in_interactive_mode = bool(getattr(sys, "ps1", sys.flags.interactive))
        if (
            debug
            or int(os.getenv("GRADIO_DEBUG", "0")) == 1
            or (not prevent_thread_lock and not is_in_interactive_mode)
        ):
            self.block_thread()
        return launch_result
